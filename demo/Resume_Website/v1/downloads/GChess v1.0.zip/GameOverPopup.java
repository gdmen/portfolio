import java.awt.*;
import javax.swing.*;

public class GameOverPopup extends PopupWindow
{
	private static final long serialVersionUID = 1400666790706351389L;
	private JLabel text;
	private JButton newGame, exit;
	
	public GameOverPopup(GUI parent, String title)
	{
		super(parent, title);
		
		text = new JLabel("The game ended in a "+title+"!");
		newGame = new JButton("New Game");
		exit = new JButton("Exit");
		newGame.setActionCommand("-10");
		exit.setActionCommand("-11");
		newGame.addActionListener(parent);
		exit.addActionListener(parent);
		
		JPanel top = new JPanel();
		top.setBackground(new Color(0,0,0,0));
		top.add(text);
		JPanel bottom = new JPanel();
		bottom.setBackground(new Color(0,0,0,0));
		bottom.add(newGame);
		bottom.add(exit);
		add(top);
		add(bottom);
		
		pack();
		resetLocation();
	}
}
