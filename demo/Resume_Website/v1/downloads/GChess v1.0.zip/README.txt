# G Chess version 1.0
# Copyright 2009, Gary Menezes

# Copyright Notice

    You may use the accompanying code under the following conditions:
    You may:
	1. Use this code for non-commercial, educational, and personal purposes.
	2. Redistribute this code *as is* along with included copyright notices.
    You may not:
	1. Use this code for any commercial purpose.
	2. Create any derivative works for redistribution.

# User Guide
    Included are all java files. The main method is in "Game.java"