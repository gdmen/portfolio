# pyRubiks Cube version 1.0
# Authors:	Gary Menezes
#		(Patrick)Yeo Ho Yoon
#		Sam Appelbaum

# A Brief Description
	A 3D rubik's cube implemented in python using PyOpenGL, NumPy, and
	wxPython. You can jumble the cube and then solve it while enjoying the
	awesomely animated rotations!

# Necessary Third Party Modules
   PyOpenGL	<http://pyopengl.sourceforge.net>
   NumPy	<http://numpy.scipy.org>
   wxPython	<http://www.wxpython.org>

# To Run
   execute run.py

# User Controls
    > Move selected face, also rotates cube to maintain view of selected face
	w / a / s / d
    > Rotate the row/column containing the selected face
	up / down / left / right arrows
    > Jumble
	space
    > Reset Cube
	r
    > Exit
	escape

# Gameplay
    Completion of the cube is not registered immediately since the cube starts
    solved. To play, first jumble the cube and then solve it using the defined
    controls. When the cube is solved, input is locked and "YOU WIN!" is
    printed to the console. To unlock the cube and play again, either reset (r)
    or jumble (space).
    A single jumble doesn't do much jumbling. For a greater challenge, jumble
    multiple times.

# Known Bugs
    Sometimes, after multiple jumbles, the display rotation becomes out of sync
    with the back end rotation (we made these separate values because of the
    interpolated animated rotations).

    Also after multiple jumbles, the selected face moves in the opposite
    direction from what it should be and after 360 degrees, corrects, and then
    after another 360 degrees switches back and repeats.

    We have only been able to unintentionally been able to reproduce these
    issues (mainly due to lack of effort). Since the assignment has already
    been turned in, we may or may not find and fix these issues.

# LICENSE
#************************************************************************#
#    pyRubiks Cube version 1.0
#    3D python Rubik's Cube
#    Copyright (c) 2010	Gary Menezes
#    Copyright (c) 2010	(Patrick)Yeo Ho Yoon
#    Copyright (c) 2010	Sam Appelbaum
#
#
#    This program is free software: you can redistribute it and/or
#    modify it under the terms of the GNU General Public License version 3 as
#    published by the Free Software Foundation.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    General Public License for more details.
#
#    A copy of the GNU General Public Licence version 3 is provided along
#    with this program in the file named LICENCE. If not, see
#    <http://www.gnu.org/licenses/>.
#**********************************************************************#