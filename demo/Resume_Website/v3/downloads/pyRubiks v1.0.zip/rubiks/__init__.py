#************************************************************************#
#    pyRubiks Cube version 1.0
#    3D python Rubik's Cube
#    Copyright (c) 2010	Gary Menezes
#    Copyright (c) 2010	(Patrick)Yeo Ho Yoon
#    Copyright (c) 2010	Sam Appelbaum
#
#
#    This program is free software: you can redistribute it and/or
#    modify it under the terms of the GNU General Public License version 3 as
#    published by the Free Software Foundation.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#    General Public License for more details.
#
#    A copy of the GNU General Public Licence version 3 is provided along
#    with this program in the file named LICENCE. If not, see
#    <http://www.gnu.org/licenses/>.
#**********************************************************************#

__doc__ = "Rubik's Cube"

__all__ = ['cube','face']
