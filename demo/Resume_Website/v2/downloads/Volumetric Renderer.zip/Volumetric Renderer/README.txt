# Volumetric Renderer
# Copyright (c) 2010 Gary Menezes

Usage notes:
To run the provided executable of this program (in release):
> CIS560_HW4_and_5.exe [config file name]
**Output filenames specified in the config file cannot
  have spaces.

Features:

4.2: Sphere
Center of sphere has density 1.
The density of position xyz = 1 - (xyz - center).length() /radius

4.3: Clouds
The density of position xyz = fbm(xyz) + (density from 4.2)
Where fbm is fractal Brownian motion, created by summing several
octaves of Perlin noise.

4.4: Pyroclastics
Included in this directory is 'example.bmp' which has a sample
cloud and a sample pyroclastic, each with radius 20.

4.5: Configuration File Handling
Input handling in fileObject.h & fileObject.cpp