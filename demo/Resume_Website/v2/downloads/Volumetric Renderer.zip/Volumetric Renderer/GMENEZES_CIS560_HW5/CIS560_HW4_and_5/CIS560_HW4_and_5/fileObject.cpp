/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#include "fileObject.h"
#define SEED (int)time(NULL)
//constructor
//@params input file name
fileObject::fileObject(string in){
	//vector of perlin objects
	for(float x = 1, y = 1; x <= 64; x*=4, y/=2){
		perlins.push_back(new Perlin(1, x, y, SEED));
	}
	//string for holding input
	string line;
	//number of primitives to read in
	int num_primitives;
	//vector for holding split input
	vector<string> split;
	//opens file 'in'
	file.open(in.c_str());

	//if the file 'in' was opened as expected
	if(file.is_open()){
		lineNum = 1;
		/*
		*  The following blocks read in and store
		*  parameters from the config file. Any
		*  unexpected file formatting will result
		*  in an error printout and an end of program
		*  execution.
		*/

		//size of a voxel edge
		if(!file.eof()){
			line = parseLine();
			delta = atof(line.c_str());
		}
		//step size for the ray march
		if(!file.eof()){
			line = parseLine();
			step = atof(line.c_str());
		}
		//dimensions of the voxelBuffer
		if(!file.eof()){
			split = parseLine(3);
			xCount = atof(split.at(0).c_str());
			yCount = atof(split.at(1).c_str());
			zCount = atof(split.at(2).c_str());
		}
		//background rgb color
		if(!file.eof()){
			split = parseLine(3);
			backR = atof(split.at(0).c_str());
			backG = atof(split.at(1).c_str());
			backB = atof(split.at(2).c_str());
		}
		//voxelBuffer material rgb color
		if(!file.eof()){
			split = parseLine(3);
			R = atof(split.at(0).c_str());
			G = atof(split.at(1).c_str());
			B = atof(split.at(2).c_str());
		}
		//output filename
		if(!file.eof()){
			split = parseLine(2);
			outfile = split.at(1);
		}
		//raytrace resolution dimensions
		if(!file.eof()){
			split = parseLine(3);
			reso_width = atof(split.at(1).c_str());
			reso_height = atof(split.at(2).c_str());
		}
		//eye position
		if(!file.eof()){
			split = parseLine(4);
			for(unsigned int i = 1; i < split.size(); i++)
				e.push_back(atof(split.at(i).c_str()));
		}
		//viewing direction
		if(!file.eof()){
			split = parseLine(4);
			for(unsigned int i = 1; i < split.size(); i++)
				v.push_back(atof(split.at(i).c_str()));
		}
		//up vector
		if(!file.eof()){
			split = parseLine(4);
			for(unsigned int i = 1; i < split.size(); i++)
				u.push_back(atof(split.at(i).c_str()));
		}
		//field of view in the y-direction
		if(!file.eof()){
			split = parseLine(2);
			fovy = atof(split.at(1).c_str());
		}
		//light position
		if(!file.eof()){
			split = parseLine(4);
			for(unsigned int i = 1; i < split.size(); i++)
				lpos.push_back(atof(split.at(i).c_str()));
		}
		//light rgb color
		if(!file.eof()){
			split = parseLine(4);
			for(unsigned int i = 1; i < split.size(); i++)
				lcol.push_back(atof(split.at(i).c_str()));
		}
		////buffer position
		//if(!file.eof()){
		//	split = parseLine(4);
		//	for(unsigned int i = 1; i < split.size(); i++)
		//		bpos.push_back(atof(split.at(i).c_str()));
		//}
		/*
		*  At this point, the config file has been read up to the start of primitive data.
		*  The next line instantiates the voxelBuffer.
		*  Then, the following loops calculate each voxel density value and write it to the
		*  voxelBuffer.
		*/
		//instantiates voxelBuffer
		voxel_buffer = new voxelBuffer(delta, xCount, yCount, zCount);//, bpos.at(0), bpos.at(1), bpos.at(2));
		
		line = "";
		//skip empty lines
		while(line == ""){
			getline(file,line);
			lineNum++;
		}
		//number of primitives
		if(line == "" && !file.eof())
			line = parseLine();
		num_primitives = atof(line.c_str());
		for(int i = 0; i < num_primitives; i++){
			line = "";
			//skip empty lines
			while(line == ""){
				getline(file,line);
				lineNum++;
			}
			if(file.eof())
				throw_eofError();
			if(line != "sphere" && line != "cloud" && line != "pyroclastic")
				throw_configFormatError();
			string type = line;
			if(!file.eof())
				split = parseLine(3);
			else
				throw_eofError();
			float r;
			if(!file.eof())
				r = atof(parseLine().c_str());
			else
				throw_eofError();
			primitives.push_back(new primitive(type, atof(split.at(0).c_str()), atof(split.at(1).c_str()), atof(split.at(2).c_str()), r));
		}

		for(unsigned int i = 0; i < primitives.size(); i++){
			cout<<primitives.at(i)->type<<endl;
			Vector3 center = Vector3(primitives.at(i)->x, primitives.at(i)->y, primitives.at(i)->z);
			if(primitives.at(i)->type == "sphere")
				for(float z = 0; z < zCount*delta; z+=delta)
					for(float y = 0; y < yCount*delta; y+=delta)
						for(float x = 0; x < xCount*delta; x+=delta){
							float length = (Vector3(x,y,z) - center).length();
							float density = 1 - length/primitives.at(i)->radius;
							if(density >= 0)
								voxel_buffer->writeDensity(x, y, z, density + voxel_buffer->readDensity(x, y, z));
						}
			else if(primitives.at(i)->type == "cloud")
				for(float z = 0; z < zCount*delta; z+=delta)
					for(float y = 0; y < yCount*delta; y+=delta)
						for(float x = 0; x < xCount*delta; x+=delta){
							float length = (Vector3(x,y,z) - center).length();
							float density = 1 - length/primitives.at(i)->radius;
							float noise = fbm(x, y, z) + density;
							if(noise >= 0)
								voxel_buffer->writeDensity(x, y, z, noise + voxel_buffer->readDensity(x, y, z));
						}
		}
		perlins.clear();
		for(float x = 8, y = 1; x <= 4096; x*=8, y/=2)
			perlins.push_back(new Perlin(1, x, y, SEED));
		for(unsigned int i = 0; i < primitives.size(); i++)
			if(primitives.at(i)->type == "pyroclastic"){
				Vector3 center = Vector3(primitives.at(i)->x, primitives.at(i)->y, primitives.at(i)->z);
				for(float z = 0; z < zCount*delta; z+=delta)
					for(float y = 0; y < yCount*delta; y+=delta)
						for(float x = 0; x < xCount*delta; x+=delta){
							float length = (Vector3(x,y,z) - center).length();
							float pyroclasm = max(1 - length/primitives.at(i)->radius + abs(fbm(x, y, z)), (float)0);
							if(pyroclasm >= 0)
								voxel_buffer->writeDensity(x, y, z, pyroclasm + voxel_buffer->readDensity(x, y, z));
						}
			}


		//makes sure any trailing lines are empty
		//if not, throw an error
		while(!file.eof()){
			getline(file,line);
			if(line != "")
				throw_eofError();
		}
		//parsing is completed, close filestream
		file.close();
	}

	//error thrown if file 'in' could not be opened
	else{
		cout<<"**FILE: "<<in<<endl;
		throw (const char*)"Unable to open file.";
	}
}
//destructor
fileObject::~fileObject(){
	delete voxel_buffer;
	for(unsigned int x = 0; x < perlins.size(); x++)
		delete perlins.at(x);
}

float fileObject::fbm(float x, float y, float z){
	float total = 0;
	x /= xCount*delta; y /= yCount*delta; z /= zCount*delta;
	for(unsigned int i = 0; i < perlins.size(); i++){
		total += perlins.at(i)->Get3D(x,y,z);
	}
	return total;
}

/*
*  helper methods to read in a line from the config
*  file and compare number of values in the line to
*  the int parameter given.
*  @exception throws an "Improper config file format"
*             exception if reading in an unexpected
*             number of parameters.
*  @return string with single value from line
*  @return vector<string> containing split line from
*          file.
*/
string fileObject::parseLine(){
	string line;
	getline(file,line);
	if(line.find_first_of(" ") != line.npos)
		throw_configFormatError();
	lineNum++;
	return line;
}
vector<string> fileObject::parseLine(int params){
	string line;
	getline(file,line);
	vector<string> splitLine = utility::stringSplit(line," ");
	if(splitLine.size() != params)
		throw_configFormatError();
	lineNum++;
	return splitLine;
}

//throws an "Unexpected end of file" string error.
void fileObject::throw_eofError(){
	cout<<"Line "<<lineNum;
	throw (const char*)": Unexpected end of file.";
}
//throws an "Improper config file format" string
//error.
void fileObject::throw_configFormatError(){
	cout<<"Line "<<lineNum;
	throw (const char*)": Improper config file format.";
}