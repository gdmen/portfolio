/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#pragma once
#include <math.h>

/*
*  A voxelBuffer object takes as parameters the size
*  of a voxel edge, and the dimensions of the voxel
*  buffer to be stored.
*  *NOTE: dimensions are 0 <= n < max, where n = x,y,z
*  Lighting values are initialized to -1.
*  Changes to density or lighting values are to be
*  made at specified voxels using the provided write*
*  functions.
*  Density and lighting values are to be read using
*  the provided read* functions.
*  @exceptions throws a string error on attempts to read
*              or write to voxels outside the defined
*              buffer.
*/
class voxelBuffer{
private:
	//1D array of voxel values
	float* voxels;
	//size of voxel edge (read in)
	float delta;
	//dimensions of the voxel buffer
	float xCount, yCount, zCount;
	//location of the voxel buffer (world space)
	float xPos, yPos, zPos;
public:
	//constructor
	//@params delta, xCount, yCount, zCount
	voxelBuffer(float d, float x, float y, float z);//, float xpos, float ypos, float zpos);
	//destructor, deletes array
	~voxelBuffer();
	//write density for a voxel
	//@params x,y,z coordinates (in world space), density value
	void writeDensity(float x, float y, float z, float d);
	//read density for a voxel
	//@params x,y,z coordinates (in world space)
	//@return density for specified voxel
	float readDensity(float x, float y, float z);
	//write lighting for a voxel
	//@params x,y,z coordinates (in world space), lighting value
	void writeLighting(float x, float y, float z, float l);
	//read lighting for a voxel
	//@params x,y,z coordinates (in world space)
	//@return lighting for specified voxel
	float readLighting(float x, float y, float z);
};