/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#pragma once
#include <string>
using namespace std;

/*
*  
*/
class primitive{
public:
	float x, y, z, radius;
	string type;
	//constructor
	//@params type, xpos, ypos, zpos, radius
	primitive(string type, float x, float y, float z, float radius);
	//destructor
	~primitive();
};