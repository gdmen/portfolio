/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/

#include "voxelBuffer.h"

//constructor
//@params delta, xCount, yCount, zCount
voxelBuffer::voxelBuffer(float d, float x, float y, float z){//, float xpos, float ypos, float zpos){
	delta = d;
	xCount = x; yCount = y; zCount = z;
	//xPos = xpos; yPos = ypos; zPos = zpos;
	voxels = new float[int(x*y*z*2)];
	for(int i = 1; i < x*y*z*2; i+=2)
		voxels[i] = -1;
	for(int i = 0; i < x*y*z*2; i+=2)
		voxels[i] = 0;
}
//destructor, deletes voxel array
voxelBuffer::~voxelBuffer(){
	delete [] voxels;
}
//write density for a voxel
//@params x,y,z coordinates (in world space), density value
void voxelBuffer::writeDensity(float x, float y, float z, float d){
	//x -= xPos; y -= yPos; z -= zPos;
	if(x >= xCount*delta || x < 0 || y >= yCount*delta || y < 0 || z >= zCount*delta || z < 0)
		return;
	x = (int)(x/delta);
	y = (int)(y/delta);
	z = (int)(z/delta);
	voxels[int((x+y*xCount+z*yCount*xCount)*2)] = d;
}
//read density for a voxel
//@params x,y,z coordinates (in world space)
//@return density for specified voxel
float voxelBuffer::readDensity(float x, float y, float z){
	//x -= xPos; y -= yPos; z -= zPos;
	if(x >= xCount*delta || x < 0 || y >= yCount*delta || y < 0 || z >= zCount*delta || z < 0)
		return 0;
	x = (int)(x/delta);
	y = (int)(y/delta);
	z = (int)(z/delta);
	return voxels[int((x+y*xCount+z*yCount*xCount)*2)];
}
//write lighting for a voxel
//@params x,y,z coordinates (in world space), lighting value
void voxelBuffer::writeLighting(float x, float y, float z, float l){
	//x -= xPos; y -= yPos; z -= zPos;
	if(x >= xCount*delta || x < 0 || y >= yCount*delta || y < 0 || z >= zCount*delta || z < 0)
		return;
	x = (int)(x/delta);
	y = (int)(y/delta);
	z = (int)(z/delta);
	voxels[int((x+y*xCount+z*yCount*xCount)*2)+1] = l;
}
//read lighting for a voxel
//@params x,y,z coordinates (in world space)
//@return lighting for specified voxel
float voxelBuffer::readLighting(float x, float y, float z){
	//x -= xPos; y -= yPos; z -= zPos;
	if(x >= xCount*delta || x < 0 || y >= yCount*delta || y < 0 || z >= zCount*delta || z < 0)
		return 0;
	x = (int)(x/delta);
	y = (int)(y/delta);
	z = (int)(z/delta);
	return voxels[int((x+y*xCount+z*yCount*xCount)*2)+1];
}
