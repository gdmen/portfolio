/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#include "fileObject.h"
#include "renderer.h"
#include <string>
#include <iostream>

using namespace std;

int main(int argc, char *argv[]){
	//filename of config file
	string configFile;
	//fileObject corresponding to config file (see fileObject.h)
	fileObject* file = NULL;
	if(argc != 2)
		return 0;
	else
		configFile = argv[argc-1];
	try{
		cout<<"Voxel Buffer Loading. . ."<<endl;
		file = new fileObject(configFile);
	}
	catch(const char* error){
		cout<<error<<endl;
		system("pause");
		return 0;
	}
	renderer::renderBuffer(file);
	if(file != NULL)
		delete file;
	system("pause");
	return 0;
}