/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#pragma once
#include <stdlib.h>
#include <gl/glut.h>
#include "SOIL.h"
#include "OgreMath.h"
#include "fileObject.h"
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>

/*
*  
*/
class renderer{
public:
	static void renderBuffer(fileObject* f);
private:
	static Vector3 rayMarch(Vector3 xc, Vector3 n, Vector3 voxelColor, Vector3 bgColor, Vector3 xl, float dS, float k, float length, voxelBuffer* v);
	static void output(unsigned char* pixels, fileObject* f);
	static float renderer::getQ(Vector3 voxel, Vector3 xl, float dS, float k, voxelBuffer* v);
};