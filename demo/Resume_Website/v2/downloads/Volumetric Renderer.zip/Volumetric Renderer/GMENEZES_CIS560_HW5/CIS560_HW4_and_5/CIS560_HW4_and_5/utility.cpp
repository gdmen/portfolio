/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#include "utility.h"

/*
*  Splits a string given a delimeter.
*  @params string to split, delimeting string
*  @return vector<string> containing split substrings
*/
vector<string> utility::stringSplit(string str, string delim){
	vector<string> results;
	int cutAt;
	while( (cutAt = str.find_first_of(delim)) != str.npos ){
		if(cutAt > 0){
			results.push_back(str.substr(0,cutAt));
		}
		str = str.substr(cutAt+1);
	}
	if(str.length() > 0){
		results.push_back(str);
	}
	return results;
}

/*
*  Calculates the cross product of two vectors.
*  @params the two vectors in u x v order.
*  @return the vector<float> z such that z = (u x v).
*/
vector<float> utility::crossProduct(vector<float> u, vector<float> v){
	vector<float> cross;
	if(u.size() != v.size()){
		throw "utility::crossProduct error - inputs of differing size.";
	}
	for(unsigned int i = 0; i < u.size(); i++)
		cross.push_back(u[(i+1)%u.size()]*v[(i+2)%v.size()] - v[(i+1)%v.size()]*u[(i+2)%u.size()]);
	return cross;
}