/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#pragma once
#include <vector>
#include <string>
using namespace std;

/*
*  The utility class contains static convenience methods that
*  might be used in multiple internal classes.
*/
class utility
{
public:
	/*
	*  Splits a string given a delimeter.
	*  @params string to split, delimeting string
	*  @return vector<string> containing split substrings
	*/
	static vector<string> stringSplit(string str, string delim);
	/*
	*  Calculates the cross product of two vectors.
	*  @params the two vectors in u x v format.
	*  @return the vector<float> z such that z = (u x v).
	*/
	static vector<float> crossProduct(vector<float> u, vector<float> v);
};
