/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#pragma once
#include "voxelBuffer.h"
#include "primitive.h"
#include "utility.h"
#include "OgreMath.h"
#include "perlin.h"
#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

/*
*  A fileObject object takes a config filename as a
*  constructor parameter and reads in the full file
*  at instantiation.
*  File information is to be accessed from the public
*  variables declared and described below.
*  @exceptions throws various string errors for improper
*              config file format.
*/
class fileObject{
public:
	//voxelBuffer object with all voxel data
	voxelBuffer* voxel_buffer;
	//vector of primitives
	vector<primitive*> primitives;
	//the size of a voxel edge
	float delta;
	//step size for ray march
	float step;
	//dimensions of voxelBuffer
	float xCount, yCount, zCount;
	//background color
	float backR, backG, backB;
	//voxel material color
	float R, G, B;
	//output filename
	string outfile;
	//resolution of raytrace
	int reso_width, reso_height;
	//eye position (world space)
	vector<float> e;
	//viewing direction (world space)
	vector<float> v;
	//up vector (world space)
	vector<float> u;
	//y-direction field of view, in degrees
	float fovy;
	//light position (world space)
	vector<float> lpos;
	//light color (RGB order)
	vector<float> lcol;
	//buffer position (bottom front left corner in world apace)
	//vector<float> bpos;

	//constructor
	//@params input file name
	fileObject(string in);
	//destructor, 
	~fileObject();
private:
	/* 
	*  The input filestream and line number are instance
	*  variables in order to facilitate putting some file
	*  parsing code into helper methods.
	*/
	ifstream file;
	//the line number is for error reporting.
	int lineNum;
	
	vector<Perlin*> perlins;
	float fbm(float x, float y, float z);
	/*
	*  Helper methods to read in a line from the config
	*  file and compare number of values in the line to
	*  the int parameter given.
	*  @exception throws an "Improper config file format"
	*             exception if reading in an unexpected
	*             number of parameters.
	*  @return string with single value from line
	*  @return vector<string> containing split line from
	*          file.
	*/
	string parseLine();
	vector<string> parseLine(int params);

	/*
	*  Helper methods that throw commonly used errors
	*  by just throwing a nonunique error with a unique
	*  error string.
	*/
	//throws an "Unexpected end of file" string error.
	void throw_eofError();
	//throws an "Improper config file format" string
	//error.
	void throw_configFormatError();
};