/*
#************************************************************************#
#    Volumetric Renderer
#    Copyright (c) 2010	Gary Menezes
#
#    You may use the accompanying code under the following conditions:
#      You may:
#        1. Use this code for non-commercial, educational, and personal purposes.
#        2. Redistribute this code *as is* along with included copyright notices.
#      You may not:
#        1. Use this code for any commercial purpose.
#        2. Create any derivative works for redistribution.
#
#    This program is distributed in the hope that it will be useful,
#    but without any warranty, implied or explicit.
#**********************************************************************#
*/
#include "renderer.h"

#define pi 3.14159265

void renderer::renderBuffer(fileObject* f){
	string fileOut = f->outfile;
	voxelBuffer* v = f->voxel_buffer;
	unsigned char* pixels = new unsigned char[(float)f->reso_width*(float)f->reso_height*3];
	/*
	for ray defined by: start = eye, end = reso_width / reso_height iteration, stepSize = step
	    
	*/
	Vector3 e = Vector3(f->e.at(0), f->e.at(1), f->e.at(2));
	Vector3 c = Vector3(f->v.at(0), f->v.at(1), f->v.at(2));
	Vector3 up = Vector3(f->u.at(0), f->u.at(1), f->u.at(2));
	//Pre-calculations:
		//A = C x U
		Vector3 A = c.crossProduct(up);
		//Vector4 A = Vector4(temp[0],temp[1],temp[2],0);

		//B = A x C
		//temp = Vector3(A[0],A[1],A[2]).crossProduct(Vector3(cfg_c[0],cfg_c[1],cfg_c[2]));
		Vector3 B = A.crossProduct(c);

		//M = E + C
		Vector3 M = e + c;

		//fovX !!
		float fovx = atan(((float)f->reso_width/(float)f->reso_height)*tan(f->fovy*pi/180.0));//((float)f->reso_width / (float)f->reso_height) * f->fovy;//acos( (cfg_up.dotProduct(B)) / (Vector3(cfg_up[0],cfg_up[1],cfg_up[2]).length() * Vector3(B[0],B[1],B[2]).length()) );
		
		//H = A*|C|*tan(fovX) / |A|
		Vector3 H = A*(c.length())*tan(fovx) / A.length();

		//V = B*|C|*tan(fovY) / |B|
		Vector3 V = B*(c.length())*tan(f->fovy*pi/180.0) / B.length();

	Vector3 xl = Vector3(f->lpos.at(0),f->lpos.at(1),f->lpos.at(2));
	Vector3 voxelColor = Vector3(f->R*f->lcol.at(0),f->G*f->lcol.at(1),f->B*f->lcol.at(2));
	Vector3 bgColor = Vector3(f->backR*f->lcol.at(0),f->backG*f->lcol.at(1),f->backB*f->lcol.at(2));
	Vector3 centerOfBuffer = Vector3(f->xCount / 2, f->yCount/2, f->zCount/2);
	float additionalLength = sqrt(pow(.5*f->xCount, 2) + pow(.5*f->yCount, 2) + pow(.5*f->zCount, 2));
	float length = pow((e - centerOfBuffer).length() + additionalLength, 2);
	
	float k = 1;
	float dS = f->step;
	int counter = 0;
	for(int y = f->reso_height-1; y >= 0 ; y--){
		cout<<(1-y/((float)f->reso_height))*100<<"%"<<endl;
		for(int x = 0; x < f->reso_width; x++){
			Vector3 P = M + (2.0*x/((float)f->reso_width-1) - 1)*H +(2.0*y/((float)f->reso_height-1) - 1)*V;
			Vector3 D = (P - e).normalisedCopy();
			Vector3 color = rayMarch(e, D, voxelColor, bgColor, xl, dS, k, length, v);

			pixels[counter] = color[0]*255;
			counter++;
			pixels[counter] = color[1]*255;
			counter++;
			pixels[counter] = color[2]*255;
			counter++;
		}
	}
	output(pixels, f);
}
Vector3 renderer::rayMarch(Vector3 xc, Vector3 n, Vector3 voxelColor, Vector3 bgColor, Vector3 xl, float dS, float k, float length, voxelBuffer* v){
	Vector3 color = Vector3(0,0,0);
	float deltaT;
	float T = 1;
	for(Vector3 x = xc; (xc - x).squaredLength() <= length; x += n*dS){
		deltaT = exp(-k * dS * v->readDensity(x[0],x[1],x[2]));
		T *= deltaT;
		if(v->readLighting(x[0],x[1],x[2]) < 0)
			v->writeLighting(x[0],x[1],x[2], getQ(x, xl, 1, k, v));
		color += T * v->readLighting(x[0],x[1],x[2]) * voxelColor * v->readDensity(x[0],x[1],x[2]) * dS;//(1 - deltaT)/k * voxelColor * T * v->readLighting(x[0],x[1],x[2]);
		if(T < .000001)
			break;
	}
	if(T > .000001)
		color += 1/k * bgColor * T * 1;
	return color;
}
float renderer::getQ(Vector3 voxel, Vector3 xl, float dS, float k, voxelBuffer* v){
	float Q = 1;
	Vector3 n = xl - voxel;
	n /= n.length();
	for(Vector3 x = voxel; (xl - x).squaredLength() >= dS; x += n*dS)
		Q *= exp(-k * dS * v->readDensity(x[0],x[1],x[2]));
	return Q;
}

void renderer::output(unsigned char* pixels, fileObject* f){
	int width, height, channels;
	width = f->reso_width;
	height = f->reso_height;
	channels = 3;
	SOIL_save_image
		(
		f->outfile.c_str(),
		SOIL_SAVE_TYPE_BMP,
		width, height, channels,
		pixels
		);
}
